module.exports = {
name: "disablechatbot",
code:`$setServerVar[chatbotchannel;1]
Successfully Disabled The Chatbot
$onlyPerms[manageserver;You Are Missing Permission - ManageServer]
`
}