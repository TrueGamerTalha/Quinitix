module.exports = {
name:"embed",
code:`
$color[GOLD]
$title[$customEmoji[heartsrainbow]ROYAL - FORCE RULES$customEmoji[heartsrainbow]]
$description[

$customEmoji[rrole_yay] 1. No Self Promotion Or Promoting Others

$customEmoji[rrole_yay] 2. No Racism/Abuse/Profanity,Treat Each Others Humbly

$customEmoji[rrole_yay] 3. No Trash Talking For Other Youtuber/Streamers.

$customEmoji[rrole_yay] 4. Use Every Channels For Their Purpose They Made For. Don't Do Any Extra Activity.

$customEmoji[rrole_yay] 5. Respect Moderators

$customEmoji[rrole_yay] 6. Do Not Ask Why Got Timed Out.

$customEmoji[rrole_yay] 7. RESPECT EACH MEMBERS

$customEmoji[rrole_yay] 8. Don't Let Anyone Spoil Your Fun In Chat And Help In Keeping Chat Clean By Reporting Spammers/Abusive Trolls.

$customEmoji[rrole_yay] 9. No Invitation Links.

$customEmoji[rrole_yay] 10. Don't Sapm In Chats Either Mod Have Power To Kich /Mute/Warn/Ban You.

$customEmoji[sprefix] What Mod Can Do If Don't Follow The Rules.

$customEmoji[rrole_yay] 11. Don't Share Your Personal Life/Photographs/Contact Number/Other Personal Thing Here Either Mod Will Ban You Permanently.

$customEmoji[rrole_yay] 12. Do Not Inpersonate Staff/Mod/Leader--This Is Something We Take Seriously,Regardless If Its A Joke Or Not.

$customEmoji[rrole_yay] 13. Listen And Respect To Everyone,Especially The Mods/Admins/Leaders.

$customEmoji[rrole_yay] 14. If Your Behaviour Is Not Deemed "Appropriate" For This Server'Mod/Staff Have The Ability To Enforce A Kick/Ban Even If Does Not Line Up With The Above Rules.

$customEmoji[rrole_yay] 15. No One Well Invites The Member From This Server To Their Server, If Found Doing That He Or She Will Be Directly Banned From This Server.

$customEmoji[rrole_yay] 16. If Member Join Another Server From Invites Of An Unknown Person Then There Will Be No Responsibility Of The Admins And mods of this server.

$customEmoji[rrole_yay] 17. Nobody Will DM The Girls Directly Without Their Permission If Found Doing That He'll Be Directly Banned From This Server.
]
$footer[$userTag] $addTimestamp
$deletecommand
$onlyforids[$botownerid;:x: only $username[$botownerid]#$discriminator[$botownerid] can use this command]`}