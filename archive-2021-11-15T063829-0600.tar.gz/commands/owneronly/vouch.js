module.exports = {
name:"+vouch",
nonPrefixed: true,
code:`
$color[GOLD]
$author[$userTag;$authorAvatar]
$description[Thank You For Vouching For VS LAND!]
$addTimestamp
$onlyForServers[871623368896573440;]
`
}