module.exports = ({
	name: 'eval',
	code: `
$eval[$message]
$onlyForIDs[613963112726659092;833590819814244370;Sorry but only the developer can use it.]`
});