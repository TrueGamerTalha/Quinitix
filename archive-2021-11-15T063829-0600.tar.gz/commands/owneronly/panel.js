module.exports = ({
name: "panel",
code: `
$title[TechHost Panel Link:]
$description[[Click Here!](https://panel.techhost.live/server/15576464)]
$color[$getVar[embedc]]
$onlyForIDs[613963112726659092;You are not authorized to run this command!]`
});