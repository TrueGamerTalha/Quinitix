module.exports = [{
name:"deny",
type:"awaitedCommand",
code:`Nuke cancelled! :sweat_drops:`}]