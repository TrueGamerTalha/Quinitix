module.exports = {
    name: "support",
    code: `https://discord.gg/hUFHaWsWTb`
}