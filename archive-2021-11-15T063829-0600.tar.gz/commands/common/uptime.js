module.exports = {
  name: "uptime",
  code: `$author[Uptime Of Spoidy;$userAvatar[$clientID]]
$description[\`\`\`
$uptime\`\`\`]
$color[$getVar[embedc]]`
}