module.exports = ({
 name: "emojify",
 code: `$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$toUppercase[$message];; ];A;🇦];B;🇧];C;🇨];D;🇩];E;🇪];F;🇫];G;🇬];H;🇭];I;🇮];J;🇯];K;🇰];L;🇱];M;🇲];N;🇳];O;🇴];P;🇵];Q;🇶];R;🇷];S;🇸];T;🇹];U;🇺];V;🇻];W;🇼];X;🇽];Y;🇾];Z;🇿];1;1️⃣];2;2️⃣];3;3️⃣];4;4️⃣];5;5️⃣];6;6️⃣];7;7️⃣];8;8️⃣];9;9️⃣];#;#️⃣];!;❕];?;❔];0;0️⃣]
$onlyIf[$noMentionMessage!=;You need to write something for converting it to emoji.]
$onlyIf[$mentioned[1]==;Please dont mention anyone. As i cant emojify mentions]
$suppressErrors`
})