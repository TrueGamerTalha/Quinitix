module.exports = ({
name: "coinflip",
aliases: ["cf", "coinflip"],
code: `$randomText[I Choose Heads;I Choose Tails]`
})