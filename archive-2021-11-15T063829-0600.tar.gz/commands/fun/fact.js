module.exports = ({
name: "fact",
code: `
$jsonRequest[https://no-api-key.com/api/v1/facts;fact]`
})